import cv2, numpy as np, warnings; warnings.filterwarnings('ignore')
from skimage.morphology import skeletonize, remove_small_objects
from scipy import ndimage as ndi
im=cv2.imread('/mnt/user-data/uploads/_Cincinnati Rail/Historic_Topo/1912_City_Topographic_Survey/Sheet_29_Mt._Auburn.jpg')
y0,y1,x0,x1=2300,3800,4000,5800
c=im[y0:y1,x0:x1]
lab=cv2.cvtColor(c,cv2.COLOR_BGR2LAB).astype(np.float32); L,a=lab[...,0],lab[...,1]-128
bga=cv2.medianBlur((a+128).astype(np.uint8),31).astype(np.float32)-128
r=np.clip(a-bga,0,None)
black=(L<100); blackd=cv2.dilate(black.astype(np.uint8),np.ones((7,7),np.uint8)).astype(bool)
m=(r>6)&~blackd; m=remove_small_objects(m,40)
sk=skeletonize(m); sk=remove_small_objects(sk,20,connectivity=2)
# integrated ink across stroke: sum of r in 7px disc / per unit length ~ box filter
ink=cv2.boxFilter(r,-1,(7,7),normalize=False)/7.0
# break at junctions
nb=ndi.convolve(sk.astype(int),np.ones((3,3)),mode='constant')-1
seg=sk&(nb<=2)
lab_,n=ndi.label(seg,np.ones((3,3)))
med=ndi.median(ink,lab_,index=np.arange(1,n+1)); size=ndi.sum(seg,lab_,index=np.arange(1,n+1))
ok=size>=15
h,e=np.histogram(med[ok],bins=30,range=(0,90),weights=size[ok]); print((h/1000).round(1)); print(e[::3])
np.save('b2_med.npy',med); 
vis=(c.astype(np.float32)*0.5+127).astype(np.uint8)
thr=float(__import__('sys').argv[1]) if len(__import__('sys').argv)>1 else 40
M=np.zeros(n+1); M[1:]=np.where(ok,med,0)
V=M[lab_]
vis[(V>0)&(V<thr)]=(255,150,0); vis[V>=thr]=(0,0,255)
cv2.imwrite('bold2_s.png',cv2.resize(vis,(900,750),interpolation=cv2.INTER_AREA))
