set -e
cd /tmp/claude-0/-home-claude/9669db83-3d5c-5670-bb77-ef568f3a22e2/scratchpad
python3 bathy/b2_grid.py
python3 bathy/b7_apply.py
python3 bathy/b7s_smooth.py
python3 bathy/b11_riffle.py
python3 bathy/b7s_smooth.py export
python3 bathy/b12_merge.py
python3 bathy/b9_lines.py
cd topo && python3 rw_maps.py && cd ..
echo ALL DONE
